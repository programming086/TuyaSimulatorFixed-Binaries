
#import <ThingSmartActivatorCoreKit/ThingSmartHomeKitActivator.h>
