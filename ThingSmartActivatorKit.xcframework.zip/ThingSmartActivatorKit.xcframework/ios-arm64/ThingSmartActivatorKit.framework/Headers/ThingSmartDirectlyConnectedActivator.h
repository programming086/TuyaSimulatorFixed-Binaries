
#import <ThingSmartActivatorCoreKit/ThingSmartDirectlyConnectedActivator.h>
