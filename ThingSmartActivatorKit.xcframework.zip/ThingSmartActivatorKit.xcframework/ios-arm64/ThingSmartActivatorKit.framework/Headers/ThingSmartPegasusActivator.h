
#import <ThingSmartActivatorCoreKit/ThingSmartPegasusActivator.h>
