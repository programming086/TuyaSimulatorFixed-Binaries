
#import <ThingSmartActivatorCoreKit/ThingSmartActivator.h>
