
#import <ThingSmartActivatorCoreKit/ThingSmartDiscovery.h>
