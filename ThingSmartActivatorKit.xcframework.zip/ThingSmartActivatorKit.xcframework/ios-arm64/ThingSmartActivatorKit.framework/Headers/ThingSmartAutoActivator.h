
#import <ThingSmartActivatorCoreKit/ThingSmartAutoActivator.h>
