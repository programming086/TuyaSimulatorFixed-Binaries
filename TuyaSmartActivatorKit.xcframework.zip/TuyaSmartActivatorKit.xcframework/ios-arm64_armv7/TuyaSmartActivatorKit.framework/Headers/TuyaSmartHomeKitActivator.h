//
// TuyaSmartHomeKitActivator.h
// TuyaSmartActivatorKit
//
// Copyright (c) 2014-2021 Tuya Inc. (https://developer.tuya.com)

#import <TuyaSmartActivatorCoreKit/TuyaSmartHomeKitActivator.h>
